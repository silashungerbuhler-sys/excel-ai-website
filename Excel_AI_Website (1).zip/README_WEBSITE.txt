Excel AI Website

1. Öffne index.html zum Ansehen.
2. Ersetze ANBIETERNAME, POSTANSCHRIFT und KONTAKT-EMAIL.
3. Ergänze vor Verkaufsstart vollständige Datenschutz- und Nutzungsbedingungen.
4. Veröffentliche den Ordner bei einem Webhoster mit HTTPS.
5. Erst die tatsächlich veröffentlichte URL bei Stripe als Website angeben.

Die Seite behauptet bewusst NICHT, dass Zahlungen bereits live sind.
